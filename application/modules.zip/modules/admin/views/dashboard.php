<?php
/**
 * Created by PhpStorm.
 * User: Nitesh
 * Date: 10/15/2015
 * Time: 7:08 PM
 */
?>

<h1>Admin Login</h1>
<?php

echo $this->session->userdata['user_data'][0]['users_name'];
?>