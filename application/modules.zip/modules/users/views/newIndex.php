 <div class="em-wrapper-area01-02-03">
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="em-wrapper-area01">
                                    <div class="menu-wrapper hidden-xs">
                                        <div id="menuleftText" class="all_categories">
                                            <div class="menuleftText-title">
                                                <div class="menuleftText"><span class="em-text-upercase">Categories</span> </div>
                                            </div>
                                        </div>
                                        <div class="menuleft">
                                            <div id="menu-default" class="mega-menu em-menu-icon">
                                                <div class="megamenu-wrapper wrapper-13_2552">
                                                    <div class="em_nav" id="toogle_menu_13_2552">
                                                        <ul class="vnav em-menu-icon effect-menu em-menu-long">
                                                            <li class="menu-item-link menu-item-depth-0 fa fa-automobile">
                                                                <a class="em-menu-link" href="#"> <span> Women’s Clothing </span> </a>
                                                                
                                                            </li>
                                                            <li class="menu-item-link menu-item-depth-0 fa fa-desktop">
                                                                <a class="em-menu-link" href="#"> <span> Men’s Clothing </span> </a>
                                                               
                                                            </li>
                                                            <li class="menu-item-link menu-item-depth-0 fa fa-camera">
                                                                <a class="em-menu-link" href="#"> <span> Eyeglasses </span> </a>
                                                                
                                                            </li>
                                                            <li class="menu-item-link menu-item-depth-0 fa fa-video-camera">
                                                                <a class="em-menu-link" href="#"> <span> Steel  Watches </span> </a>
                                                               
                                                            </li>
                                                            <li class="menu-item-link menu-item-depth-0 fa fa-university">
                                                                <a class="em-menu-link" href="#"> <span> Handbags </span> </a>
                                                              
                                                            </li>
                                                            <li class="menu-item-link menu-item-depth-0 fa fa-leaf hidden-sm ">
                                                                <a class="em-menu-link" href="#"> <span> Shoes </span> </a>
                                                            </li>
                                                            <li class="menu-item-link menu-item-depth-0 em-more-menu fa fa-tachometer hidden-sm ">
                                                                <a class="em-menu-link" href="#"> <span> Kid’s Clothing </span> </a>
                                                            </li>
                                                            <li class="menu-item-link menu-item-depth-0 em-more-menu fa fa-glass hidden-sm ">
                                                                <a class="em-menu-link" href="#home-"> <span> Garden </span> </a>
                                                            </li>
                                                            <li class="menu-item-link menu-item-depth-0 fa fa-university ">
                                                                <a class="em-menu-link" href="#"> <span> Sale Off </span> </a>
                                                            </li>
                                                            <li class="menu-item-link menu-item-depth-0 fa fa-desktop ">
                                                                <a class="em-menu-link" href="#"> <span> Furniture </span> </a>
                                                            </li>
                                                            <li class="menu-item-link menu-item-depth-0 em-more-menu fa fa-tags hidden-md hidden-sm last ">
                                                                <a class="em-menu-link" href="#"> <span> Accessories </span> </a>
                                                            </li>
                                                        </ul><!-- /.vnav -->
                                                    </div>
                                                </div>
                                            </div>
                                        </div><!-- /.menuleft -->
                                    </div><!-- /.menu-wrapper -->