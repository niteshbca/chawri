﻿
	<?php
    $logout=$this->input->get('logout');
    if($logout){
        echo "<div style='text-align:center;' class=' container alert alert-success'>".'you are successfully logged out'."</div>";
    }else{
        getInformUser();
    }
    ?>




<div class="em-wrapper-main">
                    <div class="container container-main">
                        <div class="em-inner-main">
                            <div class="em-wrapper-area02"></div>
                            <div class="em-main-container em-col1-layout">
                                <div class="row">
                                    <div class="em-col-main col-sm-24">
                                        <div class="account-login">
                                            <div class="page-title em-box-02">
                                                <div class="title-box">
                                                    <h1></h1>
                                                </div>
                                            </div>
                                          
                                                <div class="col2-set">
                                                    <div class="col-md-12 ">
                                                    <div class="content">
                                                               <h1> Chawri Online </h1>
                                                               <h5> How It Work </h5>

                                                               <p>
                                                                   Okhla,  New Delhi -110019
                                                               </p>
                                                               

                                                     </div>  
                                                        </div>
                                                    
                                                    
                                                    </div>
                                                </div>
                                            </form>
                                        </div><!-- /.account-login -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


               