<?php
/**
 * Created by PhpStorm.
 * User: Nitesh
 * Date: 10/16/2015
 * Time: 2:30 PM
 */?>


<?php
    $logout=$this->input->get('logout');
    if($logout){
        echo "<div style='text-align:center;' class=' container alert alert-success'>".'you are successfully logged out'."</div>";
    }else{
        getInformUser();
    }
    ?>

 <div class="padding-15">


 <div class="login-box">

       
<h1>Payment Now  Page.......................</h1>

 </div>
 </div>







<!-- PAGE LEVEL SCRIPTS -->

  
