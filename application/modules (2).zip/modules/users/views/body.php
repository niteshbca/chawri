<div class="em-wrapper-area01-02-03">
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="em-wrapper-area01">
                                    <div class="menu-wrapper hidden-xs">
                                        <div id="menuleftText" class="all_categories">
                                            <div class="menuleftText-title">
                                                <div class="menuleftText"><span class="em-text-upercase">Categories</span> </div>
                                            </div>
                                        </div>
                                        <div class="menuleft">
                                            <div id="menu-default" class="mega-menu em-menu-icon">
                                                <div class="megamenu-wrapper wrapper-13_2552">
                                                    <div class="em_nav" id="toogle_menu_13_2552">
                                                        <ul class="vnav em-menu-icon effect-menu em-menu-long">
                                                            <li class="menu-item-link menu-item-depth-0 fa fa-th-large">
                                                                <a class="em-menu-link" href="#"> <span> Packaging Boards Recycled Grades
 </span> </a>
                                                                
                                                            </li>
                                                            <li class="menu-item-link menu-item-depth-0 fa fa-list-alt">
                                                                <a class="em-menu-link" href="#"> <span> Packaging Boards Virgin Fibre </span> </a>
                                                               
                                                            </li>
                                                            <li class="menu-item-link menu-item-depth-0 fa fa-pencil-square-o">
                                                                <a class="em-menu-link" href="#"> <span> Paper Writing Printing </span> </a>
                                                                
                                                            </li>
                                                            <li class="menu-item-link menu-item-depth-0 fa fa-clipboard">
                                                                <a class="em-menu-link" href="#"> <span> Graphical paper & board </span> </a>
                                                               
                                                            </li>
                                                            <li class="menu-item-link menu-item-depth-0 fa fa-newspaper-o">
                                                                <a class="em-menu-link" href="#"> <span> Cup Stock Board </span> </a>
                                                              
                                                            </li>
                                                            <li class="menu-item-link menu-item-depth-0 fa fa-leaf hidden-sm ">
                                                                <a class="em-menu-link" href="#"> <span> Food Grade Paper & Board </span> </a>
                                                            </li>
                                                            <li class="menu-item-link menu-item-depth-0 em-more-menu fa fa-tachometer hidden-sm ">
                                                                <a class="em-menu-link" href="#"> <span> Soft Tissue </span> </a>
                                                            </li>
                                                            <li class="menu-item-link menu-item-depth-0 em-more-menu fa fa-glass hidden-sm ">
                                                                <a class="em-menu-link" href="#home-"> <span> Copier </span> </a>
                                                            </li>
                                                            <li class="menu-item-link menu-item-depth-0 fa fa-university ">
                                                                <a class="em-menu-link" href="#"> <span> Speciality Grades</span> </a>
                                                            </li>
                                                            <li class="menu-item-link menu-item-depth-0 fa fa-tree ">
                                                                <a class="em-menu-link" href="#"> <span> Poster </span> </a>
                                                            </li>
                                                            <li class="menu-item-link menu-item-depth-0 em-more-menu fa fa-tags hidden-md hidden-sm last ">
                                                                <a class="em-menu-link" href="#"> <span> Glassine/Butter Paper </span> </a>
                                                            </li>
                                                            
                                    <li class="menu-item-link menu-item-depth-0 em-more-menu fa fa-tags hidden-md hidden-sm last ">
                                                                <a class="em-menu-link" href="#"> <span> Thein Printing Paper </span> </a>
                                                            </li>
                                                            
                            <li class="menu-item-link menu-item-depth-0 em-more-menu fa fa-tags hidden-md hidden-sm last ">
                                                                <a class="em-menu-link" href="#"> <span> Book Cover Grades </span> </a>
                                                            </li>
                                                            
                                    <li class="menu-item-link menu-item-depth-0 em-more-menu fa fa-tags hidden-md hidden-sm last ">
                                                                <a class="em-menu-link" href="#"> <span> Stationary Paper </span> </a>
                                                            </li>
                                                            
                                        <li class="menu-item-link menu-item-depth-0 em-more-menu fa fa-tags hidden-md hidden-sm last ">
                                                                <a class="em-menu-link" href="#"> <span> Kraft </span> </a>
                                                            </li>
                                                            
                                        <li class="menu-item-link menu-item-depth-0 em-more-menu fa fa-tags hidden-md hidden-sm last ">
                                                                <a class="em-menu-link" href="#"> <span> Laminate Grades </span> </a>
                                                            </li>
                                                            
                                                            
                                                        </ul><!-- /.vnav -->
                                                    </div>
                                                </div>
                                            </div>
                                        </div><!-- /.menuleft -->
                                    </div><!-- /.menu-wrapper -->
                                  
                                </div>
                            </div>
                            <div class="col-sm-18">
                                <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
    <li data-target="#carousel-example-generic" data-slide-to="1"></li>
    <li data-target="#carousel-example-generic" data-slide-to="2"></li>
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
    <div class="item active">
      <img src="<?php echo  asset_url();?>images/chawri13.jpg" alt="...">
      <div class="carousel-caption">
        Chawri Online
      </div>
    </div>
    <div class="item">
      <img src="<?php echo  asset_url();?>images/chawri22.jpg" alt="...">
      <div class="carousel-caption">
        Chawri Online
      </div>
    </div>
    <div class="item">
      <img src="<?php echo  asset_url();?>images/chawri3.jpg" alt="...">
      <div class="carousel-caption">
        Chawri Online
      </div>
    </div>
  </div>


</div>
                                
                <div class="em-wrapper-area06">
                                <div class="em-wrapper-brands">
                                    <div class="slider-style02">
                                        <div class="em-slider em-slider-banners em-slider-navigation-icon" data-emslider-navigation="true" data-emslider-items="6" data-emslider-desktop="5" data-emslider-desktop-small="4" data-emslider-tablet="3" data-emslider-mobile="2">
                                            <div class="em-banners-item">
                                                <a href="#"><img class="img-responsive" alt="<?php echo  asset_url();?>em_brand_01.jpg" src="<?php echo  asset_url();?>images/brand/brand1.jpg"> </a>
                                            </div>
                                            <div class="em-banners-item">
                                                <a href="#"><img class="img-responsive" alt="<?php echo  asset_url();?>em_brand_02.jpg" src="<?php echo  asset_url();?>images/brand/brand2.jpg"> </a>
                                            </div>
                                            <div class="em-banners-item">
                                                <a href="#"><img class="img-responsive" alt="<?php echo  asset_url();?>em_brand_03.jpg" src="<?php echo  asset_url();?>images/brand/brand3.jpg"> </a>
                                            </div>
                                            <div class="em-banners-item">
                                                <a href="#"><img class="img-responsive" alt="<?php echo  asset_url();?>em_brand_04.jpg" src="<?php echo  asset_url();?>images/brand/brand4.jpg"> </a>
                                            </div>
                                            <div class="em-banners-item">
                                                <a href="#"><img class="img-responsive" alt="<?php echo  asset_url();?>em_brand_05.jpg" src="<?php echo  asset_url();?>images/brand/brand5.jpg"> </a>
                                            </div>
                                            <div class="em-banners-item">
                                                <a href="#"><img class="img-responsive" alt="<?php echo  asset_url();?>em_brand_06.jpg" src="<?php echo  asset_url();?>images/brand/brand6.gif"> </a>
                                            </div>
                                            <div class="em-banners-item">
                                                <a href="#"><img class="img-responsive" alt="<?php echo  asset_url();?>em_brand_07.jpg" src="<?php echo  asset_url();?>images/brand/brand7.gif"> </a>
                                            </div>
                                            
                                        </div><!-- /.em-slider -->
                                    </div>
                                </div>
                            </div><!-- /.em-wrapper-area06 -->
                                
                    <div class="row">
                        
                        <div class="col-md-3" style="width:24%">
                                
                        <div class="list-group">
  <li  class="list-group-item ">
    GSM
  </li>
  <a href="#" class="list-group-item">Less than 30</a>
  <a href="#" class="list-group-item">31 to 50</a>
  <a href="#" class="list-group-item">51-100</a>
  <a href="#" class="list-group-item">101-200</a>
  <a href="#" class="list-group-item">201-300</a>
  <a href="#" class="list-group-item">301-400</a>
  <a href="#" class="list-group-item">Above 400</a>
</div>
                    </div>
                        
            <div class="col-md-3" style="width:24%">
                                
            <div class="list-group">
  <li  class="list-group-item ">
    Size
  </li>
  <a href="#" class="list-group-item">Size 1</a>
  <a href="#" class="list-group-item">Size 2</a>
  <a href="#" class="list-group-item">Size 3</a>
  <a href="#" class="list-group-item">Size 4</a>
</div>
            
                </div>
                        
        <div class="col-md-3" style="width:24%" >
                                
                        <div class="list-group">
  <li  class="list-group-item ">
    Bulk
  </li>
  <a href="#" class="list-group-item">Bulk 1</a>
  <a href="#" class="list-group-item">Bulk 2</a>
  <a href="#" class="list-group-item">Bulk 3</a>
  <a href="#" class="list-group-item">Bulk 4</a>
</div>
                    </div>
                        
            <div class="col-md-3" style="width:24%">
                                
                        <div class="list-group">
  <li class="list-group-item ">
    Mills 
  </li>
  <a href="#" class="list-group-item">Dapibus ac facilisis in</a>
  <a href="#" class="list-group-item">Morbi leo risus</a>
  <a href="#" class="list-group-item">Porta ac consectetur ac</a>
  <a href="#" class="list-group-item">Vestibulum at eros</a>
</div>
                    </div>
                                
                                
                            </div>
                                
                <div class="row">
                        
                        <div class="col-md-3" style="width:24%">
                                
                        <div class="list-group">
  <li  class="list-group-item ">
    Packing
  </li>
  <a href="#" class="list-group-item">Less than 30</a>
  <a href="#" class="list-group-item">31 to 50</a>
  <a href="#" class="list-group-item">51-100</a>
  
</div>
                    </div>
                        
            <div class="col-md-3" style="width:24%">
                                
            <div class="list-group">
  <li  class="list-group-item ">
    Grain
  </li>
  <a href="#" class="list-group-item">Size 1</a>
  <a href="#" class="list-group-item">Size 2</a>
  <a href="#" class="list-group-item">Size 3</a>
  <a href="#" class="list-group-item">Size 4</a>
</div>
            
                </div>
                        
        <div class="col-md-3" style="width:24%" >
                                
                        <div class="list-group">
  <li  class="list-group-item ">
    PRice
  </li>
  <a href="#" class="list-group-item">Bulk 1</a>
  <a href="#" class="list-group-item">Bulk 2</a>
  <a href="#" class="list-group-item">Bulk 3</a>
  <a href="#" class="list-group-item">Bulk 4</a>
</div>
                    </div>
                        
            <div class="col-md-3" style="width:24%">
                                
                        <div class="list-group">
  <li class="list-group-item">
    Availability - Location 
  </li>
  <a href="#" class="list-group-item">Delhi</a>
  <a href="#" class="list-group-item">Noida</a>
  <a href="#" class="list-group-item">Ghaziabad</a>
  <a href="#" class="list-group-item">Etc</a>
</div>
                    </div>
                                
                                
                            </div>
                           
                        </div>
                    </div>
                </div><!-- /.em-wrapper-area01-02-03 -->
